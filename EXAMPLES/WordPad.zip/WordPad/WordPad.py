# -*- coding: UTF-8 -*-
'''
AUTHOR: Alan Pipitone
WEBSITE: http://www.alan-pipitone.com
'''

import os
import sys
import time
import subprocess
from Alexa import *

ProjectPath = os.path.dirname(os.path.realpath(__file__))
RunStartString = time.strftime("%d_%b_%Y__%H_%M_%S", time.localtime())
ExitOnError = True


def Main():
    try:

        subprocess.Popen(["C:\\Program Files (x86)\\Windows NT\\Accessories\\wordpad.exe"])

            #AppObject: font_bar
        font_bar = AppObject()
        font_bar.Name = "font_bar"
        font_bar.Height = 20
        font_bar.Width = 119
        font_bar.HeightTollerance = 20
        font_bar.WidthTollerance = 20
        font_bar.Label.Text = "Calibri"
        font_bar.Label.Language = "eng"
        font_bar.Label.Position = "inside"
        performance = font_bar.Bind(65)
        NagiosUtils.AddPerformanceData("font_bar", performance, 15, 50)
        if font_bar.TimeOut is False:
            Mouse.Click(font_bar.x + (font_bar.Width / 2), font_bar.y + (font_bar.Height / 2))
            Keyboard.InsertText("{DOWN}")
            time.sleep(1)
            Keyboard.InsertText("Arial{ENTER}")
            time.sleep(1)
            Keyboard.InsertText("Hello World{!}")
            time.sleep(1)
            Keyboard.InsertText("!{F4}")
        elif font_bar.TimeOut is True and ExitOnError is True:
            Finish()
        #end...

            #AppObject: dont_save
        dont_save = AppObject()
        dont_save.Name = "dont_save"
        dont_save.Height = 19
        dont_save.Width = 84
        dont_save.HeightTollerance = 15
        dont_save.WidthTollerance = 15
        dont_save.Label.Text = "Do.*Save"
        dont_save.Label.Language = "eng"
        dont_save.Label.Position = "inside"
        performance = dont_save.Bind(15)
        if dont_save.TimeOut is False:
            Mouse.Click(dont_save.x + (dont_save.Width / 2), dont_save.y + (dont_save.Height / 2))
        elif dont_save.TimeOut is True and ExitOnError is True:
            Finish()
        #end...

    except Exception, error:
        errorLine = str(sys.exc_traceback.tb_lineno)
        Finish("UNKNOWN: an exception has occurred at line " + errorLine +
        ": " + str(error), 3)


def Setup():

    Ocr.Data = "C:\\Alexa\\OcrData\\tessdata"

        #Alexa Log
    Log.DisableConsoleOutput()
    Log.Enable = True
    Log.DebugImages = True
    Log.Level = "debug"
    Log.Path = "C:\\Alexa\\TestCases\\WordPad\\Log\\" + RunStartString
    #end...

    #init performance data
    NagiosUtils.AddPerformanceData("font_bar", "", "", "", 3)


def Finish(message=None, exitcode=None):

    Process.Kill("wordpad.exe")

    Log.EnableConsoleOutput()

    if message is None:
        NagiosUtils.PrintOutput()
    else:
        NagiosUtils.PrintOutput(message)

    if exitcode is None:
        sys.exit(NagiosUtils.GetExitCode())
    else:
        sys.exit(exitcode)


if __name__ == '__main__':
    try:
        Setup()
        Main()
        Finish()
    except Exception, error:
        errorLine = str(sys.exc_traceback.tb_lineno)
        Finish("UNKNOWN: an exception has occurred at line " + errorLine +
        ": " + str(error), 3)
