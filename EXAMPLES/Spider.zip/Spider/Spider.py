# -*- coding: UTF-8 -*-
'''
AUTHOR: Alan Pipitone
WEBSITE: http://www.alan-pipitone.com
'''

import os
import sys
import time
import subprocess
from Alexa import *

ProjectPath = os.path.dirname(os.path.realpath(__file__))
RunStartString = time.strftime("%d_%b_%Y__%H_%M_%S", time.localtime())
ExitOnError = True


def Main():
    try:
        #Insert here your test case code

        subprocess.Popen(["C:\\Program Files\\Microsoft Games\\SpiderSolitaire\\SpiderSolitaire.exe"])

            #AppObject: beginner
        beginner = AppObject()
        beginner.Name = "beginner"
        beginner.Height = 55
        beginner.Width = 376
        beginner.HeightTollerance = 20
        beginner.WidthTollerance = 20
        beginner.Label.Text = "Beginner"
        beginner.Label.Language = "eng"
        beginner.Label.Position = "inside"
        performance = beginner.Bind(50)
        NagiosUtils.AddPerformanceData("beginner", performance, 10, 35)
        if beginner.TimeOut is False:
            Mouse.Click(beginner.x + (beginner.Width / 2), beginner.y + (beginner.Height / 2))
        elif beginner.TimeOut is True and ExitOnError is True:
            Finish()
        #end...

            #AppText: How_To_Play
        How_To_Play = AppText()
        How_To_Play.Name = "How_To_Play"
        How_To_Play.Height = 83
        How_To_Play.Width = 214
        How_To_Play.HeightTollerance = 20
        How_To_Play.WidthTollerance = 20
        How_To_Play.Text = "How To Play.*drag.*move"
        How_To_Play.Language = "eng"
        performance = How_To_Play.Bind(75)
        NagiosUtils.AddPerformanceData("How_To_Play", performance, 20, 60)
        if How_To_Play.TimeOut is False:
            pass
        elif How_To_Play.TimeOut is True and ExitOnError is True:
            Finish()
        #end...

        Keyboard.InsertText("!{F4}")

    except Exception, error:
        errorLine = str(sys.exc_traceback.tb_lineno)
        Finish("UNKNOWN: an exception has occurred at line " + errorLine +
        ": " + str(error), 3)


def Setup():

    Ocr.Data = "C:\\Alexa\\OcrData\\tessdata"

        #Alexa Log
    Log.DisableConsoleOutput()
    Log.Enable = True
    Log.DebugImages = True
    Log.Level = "debug"
    Log.Path = "C:\\Alexa\\TestCases\\Spider\\Log\\" + RunStartString
    #end...

    #Init here your Nagios Data Source
    NagiosUtils.AddPerformanceData("beginner", "", "", "", 3)
    NagiosUtils.AddPerformanceData("How_To_Play", "", "", "", 3)



def Finish(message=None, exitcode=None):

    Log.EnableConsoleOutput()

    if message is None:
        NagiosUtils.PrintOutput()
    else:
        NagiosUtils.PrintOutput(message)

    if exitcode is None:
        sys.exit(NagiosUtils.GetExitCode())
    else:
        sys.exit(exitcode)


if __name__ == '__main__':
    try:
        Setup()
        Main()
        Finish()
    except Exception, error:
        errorLine = str(sys.exc_traceback.tb_lineno)
        Finish("UNKNOWN: an exception has occurred at line " + errorLine +
        ": " + str(error), 3)
